int checkeod(int n) {
    return n % 2;
}